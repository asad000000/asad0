package Interfaces;

public interface Car {
}
