package com.rawcubes.Abstraction;

 abstract class BMW {
    void commFun(){
        System.out.println("inside common function");
    }
    abstract  void accelerate();
    public static void main(String[] args) {
        System.out.println("inside main method ");
    }
}
