package com.rawcubes.Abstraction;

public class FiveSeries extends BMW{
    @Override
    void accelerate() {
        System.out.println("inside five series accelerate method");
    }
}
