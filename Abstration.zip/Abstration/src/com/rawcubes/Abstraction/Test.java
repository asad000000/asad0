package com.rawcubes.Abstraction;

public class Test{
    public static void main(String[] args){
        ThreeSeries ts = new ThreeSeries();
        ts.accelerate();
        ts.commFun();
        FiveSeries fs = new FiveSeries();
        fs.acceletare();
        fs.commFun();
    }
}