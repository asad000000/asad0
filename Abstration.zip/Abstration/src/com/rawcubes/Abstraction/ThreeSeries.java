package com.rawcubes.Abstraction;

public class ThreeSeries extends  BMW{

    @Override
    void accelerate() {
        System.out.println("inside three series  accelerate method");
    }
}
