package com.emc.Test;

import com.emc.entity.Organizer;
import com.emc.entity.Event;

public class Testter {
    public static void main(String[] args) {
        Organizer oz=new Organizer();
        oz.id=123L;
        oz.name="asad";
        System.out.println(oz);
        System.out.println(oz.id);
        System.out.println(oz.name);
        Event event =new Event(124l,"opening company","future");
  //    event.id=124l;
        //event.description="opening company";
       //event.startTime="past";
      //  event.startTime="future";
       // event.started=true;
        System.out.println(event.id);
        System.out.println(event.description);
        System.out.println(event.startTime);
       // System.out.println(event.started);

    }
}
