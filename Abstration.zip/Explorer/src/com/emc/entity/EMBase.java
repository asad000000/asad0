package com.emc.entity;

public class EMBase {
    public Long id;
    public String name;
}
