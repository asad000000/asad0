package com.emc.entity;

public class Event extends EMBase {

    public String description;
    public  String startTime;
    public  String endTime;
    public  Boolean started;
    public  Event(Long id,String description,String startTime){
        this.id=id;
        this.description=description;
        this.startTime=startTime;

    }
}
