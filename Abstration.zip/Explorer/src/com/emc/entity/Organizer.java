package com.emc.entity;

public class Organizer extends EMBase {


}
