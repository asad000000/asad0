package com.emc.entity;

public class Participant extends EMBase {

    public  String email;
    public  Boolean checkIn;

}
