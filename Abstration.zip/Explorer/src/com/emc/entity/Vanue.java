package com.emc.entity;

public class Vanue extends EMBase{

    public String description;
    public  String city;
    public  String state;
    public  String country;
    public  String pincode;
}
