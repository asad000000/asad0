package Pack;
import java.util.Scanner;
import static java.lang.Integer.*;
import  static java.lang.System.out;
public class ImportExample {
    public static void main(String arg[])
    {
        out.println("enter two integers");
        Scanner sc=new Scanner(System.in);
        int num1=parseInt(sc.next());
        int num2=parseInt(sc.next());
        int result=num1+num2;
        out.println("sum is "+result);
}
