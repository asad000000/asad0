package CounstractorPackage;

public class ChildClass extends SuperClass {
    ChildClass(){
        this(5);
        System.out.println("no args child constructor");
    }
    ChildClass(int x){
        super(x);
        System.out.println("no args child constructor");
    }
    public static void main(String[] args) {
        ChildClass cc=new ChildClass();

    }

}
