package CounstractorPackage;

import CounstractorPackage.Parents;

public class Childs extends Parents {
    int c,d;
    Childs(int a, int b, int c, int d){
        super(a,b);
        this.c=c;
        this.d=d;
    }
    void display(){
        System.out.println("parent variable of a "+super.a);
        System.out.println("parent variable of b "+super.b);
        System.out.println("child variable of c "+this.c);
        System.out.println("child variable of d "+this.d);
    }
    void f2(){
        super.f1();
       /*allow */   //System.out.println(this);
     /*not allowed*/  // System.out.println(super);
        System.out.println("inside child f2 method");

    }
}
