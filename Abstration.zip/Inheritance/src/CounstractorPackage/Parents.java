package CounstractorPackage;

public class Parents {
    int a,b;
    Parents(int a, int b){
        this.a=a;
        this.b=b;

    }
   void f1(){
       System.out.println("inside parent f1 method");

   }
}
