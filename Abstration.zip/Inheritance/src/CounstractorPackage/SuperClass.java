package CounstractorPackage;

public class SuperClass {
    int x;
    SuperClass(){
        System.out.println("no args super class constructor");
    }
    SuperClass(int x){
        this.x=x;
        System.out.println("args super class constructor");
    }


}
