package CounstractorPackage;

public class Tests {
    public static void main(String[] args) {
        Childs c=new Childs(4,5,6,7);
        c.f2();
        c.display();

    }
}
