package HighricalInheritance;

public class Bike extends  Vichle{
    String fuel(){
        return "petrol";
    }
}
