package HighricalInheritance;

public class Bus extends Vichle{
    String fuel(){
        return "CNG";
    }
}
