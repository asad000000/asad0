package HighricalInheritance;

public class Car extends Vichle{
    String fuel(){
        return "Diesel";
    }
}
