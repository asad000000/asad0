package HighricalInheritance;

public class Vichle {
    String fuel(){
        return "petrol";
    }
}
