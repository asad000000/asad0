package InheritanceExample;

public class Manager extends Employee {
    String[] project;
    public Manager(int id, String name,String dept,double salary,String[] project) {
        super(id, name,dept, salary);
        this.project=project;
    }
    @Override
     protected void work(){
        super.work();
        System.out.println("Manager is managing"+project);
        for (int i=0;i< project.length;i++){
            System.out.println(project[i]);
        }
    }
}
