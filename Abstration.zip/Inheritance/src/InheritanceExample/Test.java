package InheritanceExample;

public class Test {
    public static void main(String[] args) {
        String[] project = new String[]{"coding", "testing"};
        Manager manager = new Manager(12, "rok", "it", 120000, project);
        System.out.println(manager.id);
        System.out.println(manager.name);
        System.out.println(manager.dept);
        System.out.println(manager.salary);
        manager.work();
    }
}