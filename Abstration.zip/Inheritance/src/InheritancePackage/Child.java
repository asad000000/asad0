package InheritancePackage;

public class Child extends Parent {
    Child(){
        System.out.println("inside f2 method" +this);
    }
    public  void  f2(){
        System.out.println("inside Child class f2 method ");
    }
}
