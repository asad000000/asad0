package InheritancePackage;

public class Jdk6 {
  public  void   jdk6(){
        System.out.println("instantiating jdk6");
    }
}
