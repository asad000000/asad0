package InheritancePackage;

public class Jdk7 extends Jdk6{
     public void jdk7(){
        System.out.println("instantiating jdk7");
    }
}
