package InheritancePackage;

public class Jdk8 extends Jdk7{
    public  void jdk8(){
        System.out.println("instantiating jdk8");
    }
}
