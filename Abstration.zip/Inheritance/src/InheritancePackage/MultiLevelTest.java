package InheritancePackage;

public class MultiLevelTest {
    public static void main(String[] args) {
        Child c=new Child();
       // c.f1();
        //c.f2();
        c.hashCode();
    }
}
