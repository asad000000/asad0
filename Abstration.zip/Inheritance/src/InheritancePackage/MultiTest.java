package InheritancePackage;

public class MultiTest {
    public static void main(String[] args) {
        Jdk8 jdk8=new Jdk8();
        jdk8.jdk7();
        jdk8.jdk6();
    }

}
