package InheritancePackage;

public class Parent {
    Parent(){
        System.out.println("inside f1 method"+this);
    }
    public  void  f1(){
        System.out.println("inside Parent class f1 method ");
    }
}
