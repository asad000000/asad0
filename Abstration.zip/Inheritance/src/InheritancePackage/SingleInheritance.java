package InheritancePackage;

public class SingleInheritance {
    public void m1(){
        System.out.println("inside SingleInheritance class m1 method");
    }

    public static void main(String[] args) {
        SingleInheritance si=new SingleInheritance();
        si.m1();
    }
}
