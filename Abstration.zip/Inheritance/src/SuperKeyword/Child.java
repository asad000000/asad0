package SuperKeyword;

public class Child extends Parent {
    int y,z;
    Child(int w,int x,int y,int z){
        super(w,x);
        this.y=y;
        this.z=z;
    }
    void display(){
        System.out.println("parent variable of a "+super.w);
        System.out.println("parent variable of b "+super.x);
        System.out.println("child variable of c "+this.y);
        System.out.println("child variable of d "+this.z);
    }
    void f2(){
        super.f1();
       /*allow */   //System.out.println(this);
     /*not allowed*/  // System.out.println(super);
        System.out.println("inside child f2 method");

    }
}
