package SuperKeyword;

public class Parent {
    int w,x;
    Parent(int w,int x){
        this.w=w;
        this.x=x;

    }
   void f1(){
       System.out.println("inside parent f1 method");

   }
}
