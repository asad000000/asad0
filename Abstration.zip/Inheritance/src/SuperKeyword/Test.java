package SuperKeyword;

public class Test {
    public static void main(String[] args) {
        Child c=new Child(4,5,6,7);
        c.f2();
        c.display();

    }
}
