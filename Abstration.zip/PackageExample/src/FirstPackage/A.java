package FirstPackage;

public class A {
    public static void add(){
        int a=10;
        int b=20;
        System.out.println("addition"+(a+b));
    }
    public  void sub(){
        int c=10;
        int d=30;
        System.out.println("subtraction"+(c-d));
    }


}
