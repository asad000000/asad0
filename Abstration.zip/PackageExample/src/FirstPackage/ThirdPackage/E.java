package FirstPackage.ThirdPackage;

public class E {
        public void e1(){
            System.out.println("inside e1 class ");
        }
}
