package FirstPackage;
import static FirstPackage.A.*;
import FirstPackage.ThirdPackage.E;

public class b {
    public static void main(String[] args) {
       A.add();
        A a=new A();
        a.sub();
        E e=new E();
        e.e1();

    }
}
