package SecondPackage;

public class A {
    public static void add(){
        System.out.println("inside second package as A class ");
    }
}
