package SecondPackage;
import  FirstPackage.A;

public class C {
    public static void main(String []args) {
        A.add();
        A obj = new A();
        obj.sub();


    }
}