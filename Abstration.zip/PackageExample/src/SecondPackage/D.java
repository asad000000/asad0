package SecondPackage;
import FirstPackage.A;

public class D {
    public static void main(String[] args) {
        A.add();
        SecondPackage.A.add();

    }
}
