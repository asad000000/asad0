package com.rawcubes.FlowControl;

public class SwitchCaseEx {
    public static void main(String[] args) {
        String choice="check balance";
        switch(choice){
            case "check balance":
            System.out.println("check balance");
            break;
            case "withdraw money":
                System.out.println("withraw money");
                break;
            case "debit money":
            default:
                System.out.println("time out");
        }

    }
}
