package com.rawcubes.example2;

public class CommmandLineArguments {
    public static void main(String[] args) {
        int length =args.length;
        if(length==0){
            System.out.println("number input provided");
        }else{
            System.out.println("list os arguments");
            for(int i=0;i<length;i++){
                System.out.println(args[i]);
            }
        }
    }
}
