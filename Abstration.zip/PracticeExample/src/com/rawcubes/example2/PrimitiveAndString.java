package com.rawcubes.example2;

public class PrimitiveAndString {
    public static void main(String[] args) {
  /* 1..     byte x=100;
        String s=Byte.toString(x);
        byte y=Byte.parseByte(s);*/
      /*2... long l=100;
        Long a=new Long(l);
        String s="2000";
        Long b=new Long(s); */

    }
}
